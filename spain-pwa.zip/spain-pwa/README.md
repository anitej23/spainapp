# Spain Trip 2026 — PWA

A Progressive Web App travel guide for Madrid, Seville, and Barcelona.

## Files
- `index.html` — The full app (single page)
- `manifest.json` — PWA config
- `sw.js` — Service worker (offline support)
- `icon-192.png` / `icon-512.png` — App icons

## Install on iPhone
1. Open the link in **Safari** (must be Safari, not Chrome)
2. Tap the **Share** button (box with arrow)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **Add** — it installs like a native app
5. Works offline once installed ✓

## Deploy to GitHub Pages
1. github.com → New repository → `spain-trip-2026` → Public → Create
2. Upload all 5 files → Commit changes
3. Settings → Pages → Branch: main → Save
4. Live at: `https://YOUR-USERNAME.github.io/spain-trip-2026`

## Or: Netlify Drop (instant, no account)
1. Go to https://app.netlify.com/drop
2. Drag the `spain-pwa` folder onto the page
3. Get a public URL instantly
