# Spain Family Trip 2026 — PWA

Personal travel guide for Madrid, Seville, and Barcelona. Installs to your iPhone home screen.

## Files
- `index.html` — The full app
- `manifest.json` — PWA config (name, icons, colors)
- `sw.js` — Service worker (offline support)
- `icon-192.png` / `icon-512.png` — App icons
- `.github/workflows/deploy.yml` — Auto-deploys on every push

## How to deploy (one-time setup)

### Step 1 — Create the repo
1. Go to github.com → click **+ New repository**
2. Name it `spain-trip-2026` → set to **Public** → click **Create**

### Step 2 — Upload ALL the files
1. Click **"uploading an existing file"**
2. Drag in ALL 6 files AND the `.github` folder:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon-192.png`
   - `icon-512.png`
   - `.github/workflows/deploy.yml` ← this triggers the action
3. Click **Commit changes**

### Step 3 — Enable GitHub Pages (one time)
1. Go to **Settings** → **Pages** (left sidebar)
2. Under "Build and deployment" → Source → select **GitHub Actions**
3. Click **Save**

GitHub will now auto-deploy every time you push a change. The Actions tab will show a green checkmark when live.

Your site: `https://anitej23.github.io/spain-trip-2026`

## Install on iPhone
1. Open the URL in **Safari** (not Chrome — must be Safari)
2. Tap the **Share** button (box with arrow pointing up)
3. Scroll down → tap **"Add to Home Screen"**
4. Tap **Add** — it installs like a native app
5. Works completely offline once installed ✓
